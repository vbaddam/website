import "./styles.css";

export default function App() {
  return (
    <nav className="nav-style">
      <div>Home</div>
      <div>About Publications</div>
    </nav>
  );
}
