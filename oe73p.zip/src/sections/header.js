//import "./syles.css";
import React from "react";

export default function Header() {
  return (
    <nav className="nav-style">
      <div>Home</div>
      <div>About Publications</div>
    </nav>
  );
}
